const treeData = {
    name: "Domain Controller",
    children: [
        { 
            name: "Servers", 
            children: [
                { name: "Web Server" },
                { name: "Database Server" }
            ]
        },
        { 
            name: "OU - Finance", 
            children: [
                { name: "Finance Manager" },
                { name: "Accountant" }
            ]
        },
        { 
            name: "OU - IT Dept", 
            children: [
                { name: "Admin User" },
                { name: "Regular User" }
            ]
        }
    ]
};

// Security controls info
const securityInfo = {
    "Domain Controller": { control: "A.9.2.1", protection: "Secure authentication, logging, and access restrictions." },
    "Servers": { control: "A.12.1.1", protection: "Regular patching, backups, and monitoring." },
    "Web Server": { control: "A.13.1.2", protection: "Firewall rules, WAF protection, and TLS encryption." },
    "Database Server": { control: "A.14.2.5", protection: "Encrypted storage, least privilege access, and regular audits." },
    "OU - Finance": { control: "A.10.1.1", protection: "Access control policies and financial data encryption." },
    "Finance Manager": { control: "A.9.4.2", protection: "Multi-factor authentication and role-based access control." },
    "Accountant": { control: "A.9.4.3", protection: "Limited financial system access and transaction logging." },
    "OU - IT Dept": { control: "A.12.5.1", protection: "System monitoring and admin access restrictions." },
    "Admin User": { control: "A.9.2.3", protection: "Privileged account management and session monitoring." },
    "Regular User": { control: "A.9.3.1", protection: "General access control and security training." }
};

// Set dimensions
const width = window.innerWidth;
const height = window.innerHeight;

// Create zoom behavior
const zoom = d3.zoom()
    .scaleExtent([0.5, 2])
    .on("zoom", (event) => svgGroup.attr("transform", event.transform));

// Append SVG
const svg = d3.select("svg")
    .call(zoom)  // Enable zooming
    .append("g");

// Create hierarchical data
const root = d3.hierarchy(treeData);
const treeLayout = d3.tree().size([height, width - 200]);
treeLayout(root);

// Create links
svg.selectAll("line")
    .data(root.links())
    .enter()
    .append("line")
    .attr("class", "link")
    .attr("x1", d => d.source.y)
    .attr("y1", d => d.source.x)
    .attr("x2", d => d.target.y)
    .attr("y2", d => d.target.x);

// Create nodes
const nodes = svg.selectAll("g")
    .data(root.descendants())
    .enter()
    .append("g")
    .attr("transform", d => `translate(${d.y},${d.x})`)
    .on("click", (event, d) => showInfo(d.data.name));

// Add circles for nodes
nodes.append("circle")
    .attr("r", 6)
    .attr("fill", "cyan")
    .on("click", (event, d) => animateNode(event.currentTarget));

// Add text labels ABOVE nodes
nodes.append("text")
    .attr("dy", "-10") // Moves label above node
    .text(d => d.data.name);

// Show info on click
function showInfo(nodeName) {
    const panel = document.getElementById("info-panel");
    const title = document.getElementById("info-title");
    const description = document.getElementById("info-description");

    const info = securityInfo[nodeName] || { control: "N/A", protection: "No details available" };
    
    title.innerText = nodeName;
    description.innerHTML = `<strong>ISO 27001 Control:</strong> ${info.control}<br><br>
                             <strong>Protection Measures:</strong> ${info.protection}`;

    panel.style.display = "block";
}

// Hide info panel
function hideInfo() {
    document.getElementById("info-panel").style.display = "none";
}

// Add jiggle effect
function animateNode(node) {
    d3.select(node)
        .transition()
        .duration(100)
        .attr("transform", "scale(1.2)")
        .transition()
        .duration(100)
        .attr("transform", "scale(1)");
}
nodes.append("text")
    .attr("dy", "-10") // Moves label above node
    .attr("fill", "white")  // <-- Ensures text is white
    .text(d => d.data.name);
function hideInfo() {
    document.getElementById("info-panel").style.display = "none";
}
// Data for security controls & threats
const infoData = {
    "Domain Controller": {
        controls: "ISO 27001 Control: A.9.2.1 - User Access Management",
        threats: "Threat: Pass-the-Hash Attacks, Unauthorized Privilege Escalation"
    },
    "Servers": {
        controls: "ISO 27001 Control: A.12.1.1 - Malware Protection",
        threats: "Threat: Ransomware, Remote Code Execution"
    },
    "OU - Finance": {
        controls: "ISO 27001 Control: A.18.1.3 - Compliance with Security Policies",
        threats: "Threat: Phishing, Financial Fraud"
    }
};

// State tracker for toggling between controls & threats
let currentNode = null;
let currentPage = "controls"; // Default view

function showInfo(nodeName) {
    currentNode = nodeName;
    currentPage = "controls"; // Reset to default page
    updateInfoPanel();
    document.getElementById("info-panel").style.display = "block";
}

function updateInfoPanel() {
    if (!currentNode) return;

    let content = currentPage === "controls" ? infoData[currentNode].controls : infoData[currentNode].threats;
    document.getElementById("info-content").textContent = content;
}

function showPrevious() {
    currentPage = "controls";
    updateInfoPanel();
}

function showNext() {
    currentPage = "threats";
    updateInfoPanel();
}

function hideInfo() {
    document.getElementById("info-panel").style.display = "none";
}
